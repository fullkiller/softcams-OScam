********************************************************************
* CCcam2.3.2-de (ARM) with DE support based on original CCcam2.3.2 *
********************************************************************

1) Find binary file in the folder /usr/bin or /bin on your recievier with name for example CCcam2.3.0 
2) Rename new CCcam2.3.2-de.arm file to CCcam2.3.0 (NEW NAME MUST BE SAME AS EXIST NAME ON YOUR RESEIVER)
3) Stop emulator on your receiver
4) Replace exist cccam binary file with new one
5) Reboot receiver
